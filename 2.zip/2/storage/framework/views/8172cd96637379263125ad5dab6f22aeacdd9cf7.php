<?php
if (Auth('admin')->User()->dashboard_style == "light") {
    $text = "dark";
} else {
    $text = "light";
}
?>

    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('admin.topmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="main-panel">
			<div class="content bg-<?php echo e(Auth('admin')->User()->dashboard_style); ?> ">
				<div class="page-inner">
					<div class="mt-2 mb-4">
					<h1 class="title1 text-<?php echo e($text); ?>">User Plan</h1>
					</div>
					<?php if(Session::has('message')): ?>
					<div class="row">
						<div class="col-lg-12">
							<div class="alert alert-info alert-dismissable">
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								<i class="fa fa-info-circle"></i> <?php echo e(Session::get('message')); ?>

							</div>
						</div>
					</div>
					<?php endif; ?>
		
					<?php if(count($errors) > 0): ?>
					<div class="row">
						<div class="col-lg-12">
							<div class="alert alert-danger alert-dismissable" role="alert" >
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<i class="fa fa-warning"></i> <?php echo e($error); ?>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
					<?php endif; ?>
					
					<div class="mb-5 row">
						<div class="col card shadow p-4 bg-<?php echo e(Auth('admin')->User()->dashboard_style); ?>">
							<div class="table-responsive" data-example-id="hoverable-table"> 
								<table id="ShipTable" class="table table-hover text-<?php echo e($text); ?>"> 
									<thead> 
										<tr> 
											<th>Client name</th>
											<th>Amount</th>
											<th>Plan</th>
											<th>Active</th> 
											<th>Date created</th>
											<th>Option</th>
										</tr> 
									</thead> 
									<tbody> 
										<?php $__currentLoopData = $userplan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr> 
											<td><?php echo e($deposit->duser->name); ?></td>
											<td><?php echo e($settings->s_currency); ?><?php echo e($deposit->amount); ?></td> 
											<td><?php echo e($deposit->dplan->name); ?></td>
                                            <td><?php echo e($deposit->active); ?></td> 
											<td><?php echo e(\Carbon\Carbon::parse($deposit->created_at)->toDayDateTimeString()); ?></td> 
											<td>
												<a href="#" class="m-1 btn btn-info btn-sm" data-toggle="modal" data-target="#bkModal<?php echo e($deposit->id); ?>"> Back Date</a>
											</td> 
										</tr> 
										
										<!-- View info modal-->
										<div id="bkModal<?php echo e($deposit->id); ?>" class="modal fade" role="dialog">
											<div class="modal-dialog">
				
												<!-- Modal content-->
												<div class="modal-content">
													<div class="modal-header bg-<?php echo e(Auth('admin')->User()->dashboard_style); ?> ">
														<h4 class="modal-title text-<?php echo e($text); ?>">Back Date</strong></h4>
									 					<button type="button" class="close text-<?php echo e($text); ?>" data-dismiss="modal">&times;</button>
													</div>
													<div class="modal-body bg-<?php echo e(Auth('admin')->User()->dashboard_style); ?>">
														<form role="form" method="post" action="<?php echo e(route('backdateinvest')); ?>">
															<?php echo csrf_field(); ?>
															<input  class="form-control bg-<?php echo e(Auth('admin')->User()->dashboard_style); ?> text-<?php echo e($text); ?>" name="date" type="datetime-local"><br/>
															
															<input  type="hidden" name="id" value="<?php echo e($deposit->id); ?>"><br/>
														<input type="submit" class="btn btn-<?php echo e($text); ?>" value="Submit">
													</form>
													</div>
												</div>
											</div>
											</div>
											<!--End View info modal-->

										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody> 
								</table>
							</div>
						</div>
					</div>
				</div>	
			</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\VICTORY.E\Documents\Brynamics\New Version\Online-Trade-2021\resources\views/admin/userplan.blade.php ENDPATH**/ ?>