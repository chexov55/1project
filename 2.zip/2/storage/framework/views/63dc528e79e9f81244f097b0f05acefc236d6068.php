<?php echo e($slot); ?>

<?php /**PATH C:\Users\VICTORY.E\Documents\Brynamics\New Version\Online-Trade-2021\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>