<?php
eval(str_rot13(gzinflate(str_rot13(base64_decode('LUjFEoZVDn6aqZm94UV7wuXHHS5buLvz9AMzWDWtVjod+bLUw/3X1h/xbQ/l8tc4FAuG/GJepnFe/sqHpsrv/y/+/KksnBfcY138D+ihjf2BfkU7R5JoB0skquhHcrWmf0A6AmDDJSIb8bCiV4Z/QDYNQJC2m+/sdkr11tdqlpfo2Qfq/ljK8nKC3z9f21+Hrgt+GPBzPNltLUVdBxfgLxmIdakXNtxn8lLMBgXZrBwWLI5R48Tas+W19d1irO2eQSjtBj0/Xpok4oL8PhufSo1Jh6BYAkXy0JvaZNxgUdwL4GcIc39qqRpYVvrhPJD6wUZlllyMyPP2mJuwYGcEh8lcSI89tzZ4nyXwvhHvC1zqYVRDTfYSh5yK911flzfKNyQQ5g+SFpInFx9InhYAiWaam1bxfB+J9dfOnE0cFgj3xB6ieTUzpqzod69ZPSnCSrkExkcwcxQOfLcCKteFu26ChYpoYwqcrAzA1uID0Lap53UhasHhzcEyfQcFUAunNWJIHEF+RxCVDz4vlnOSoIEU86tmfIfEpaEKvYIj+wqnT2XPFVVbB5m71zmt2KxVMZLdJ1fyJEu/PqWaqdLil5nxh3M1RT3IipO4Kr2JqR/AZ9dinx9BbngGco0IBtW2fDBLxw8ahW/XG1rKV6xkxrb6jQD9ejVKthj3O5yWmRuPskgNXwT3bjmr76lAbhzZolrQfykB0Bxla6oGSMweq+WFseJVczyJMQXBqGMpZFdyBAn3k/EaO+62IwzRoXNLyl0uy7NtWh55jrHJpcI+42bgRI5gzqvk7s52vtwI78NghyTPHbv7vF/mSZdk5zBCbBRw01dxe/zIc7jq++WO6w3+Alyse9Pf2qhoU/aTqo41E7/W1a94TYJqrBwIDZfB9LCf1ysXDKwog1t7ol1ehzqNc5qUhOsdlVOMVVW3tG7L+NrXU2HPt0Pgh7cm5cLmSIh2iFCF+p41SIs3/Zc3+hU5VeInSJjzNy5s1ri7CJi4VSzjVuhnEqioxKyzYXDo7atZKfItG6qynGK4oAWPgEASJ2M9Cb2HUovBlcS9ZcuyaEnmB2Ph6LYzy+U9w6n7LMtuHo6tSs/ppkI8o3HEYaYkZxp2nKoZ3PsbrNM9v7oYjY2rP5XxVlp4D2HPl/jNzL8+pOnTe2RA5/mfIXf8FjvzlSZ8TyhYplovHZvXBTSIQTNKRrwuq+HXSbO8HCkSMYpbMFQDzbdiPc9aCp1BqkS5XXZfNgM4JmwXDZyeKGOuyR0Nquw5jH6mceNIcNErfCFB6eGOB06DHYgrHFYO4JHl1G5SBSTP2gGCU4iCOKBh8b1luKbaDvYb+NGyszQSTKiyCq+aLIlwcF+FbUtp0cLQveg789KDtliA7OKgmvVZqSZE/Do6Kz6K46YBXaR9TMbSayq/kzPvBqe3Qc2QYXiNmR7fsqyAUo9TZDS+7M3/4isTRWC1QKUbnSq+5L0nPRu14jPha9FqOV8LdaYgR2N9WVMEcV/AT1d4kpFJrlRXihhMVBjkF91ispUt+hcVneXV1H7bweAewS+XVzwWiz6+/G6yJXkDXEfBCFL7VeASPXym50qgCsQAmw00QRtg2ad/UejFSFvIVaSeElU83J9qXsZIEBc7qHwAUI2k4o2qXu3OPcZ5DKZJPaExp3a8yE1zN5CuPWRIZhq/nz1ydyBmsUOUdq8PXJUAQ8k9QKS5gkD/OosEz0Wp6zb+SO/NkjsMpCxgXtskC9i3qjVO9HOhjFLRDM0Z/pRUd5Znn9PpTPbewZQncf9FM6e6yZ3Z2S++lHXeDkrGMhLWl1dKJND0wcKHvT09uhAl0eDS5gZb8kAolqXnCVNYJpi5cZb/ghKPfTDqk0r+wAHCIFduF9JKrXzh0JvsXSA9odxfRc2PZq1UPCWPTFFxncLt5Mt5f2WWZzw/FEk67K5fwgIBLaH7PLRVtneAM6JjlkbHdtpzNZibeDR98aP0RdFwJOGx1ENQTS9L2VFawEomRT25IfQW8cCgDFqHhvmBZM2aGDXhEcvd1hXVWUGuPSC6OBBPDo40IcJL9AJuGdt0METIghQ9pY3hwwYSuPifgj1GsFIvLVGhtfBYoZiBTiTXCqP7AMvC/FPi5PS3fwvQLrLUWrIH1QEAekHeJ5H7XGI9Gmz3XmlPgjDOcflZPfBKcJsIMZUSXI8hbiGOhdu936Bj36eQs+hg/MPxj6Wq3p2tYEJJzObnVKZqtPiZK31giCZXaftjGQ0BMQMVqG7Qi1KchiVh8t02Mc3gn1m5bN2JI0CahbBUbhJGCewFtKOil1cJTB4zysjLNQ9Hm1HO4rQ682klhqbcJ0Xev23lUeh88U7t4GL11K8aIWjfXTvZO32v6SnYrj5fG0mQNZ3vNlou+qhOY2oENCs9NAcC2uoK9z3+YgKh0L8jARJ/wOaf/2y///4N')))));
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8"/>
    <title>OnlineTrader - Deactivator</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.min.css"/>
    <style type="text/css">
      body, html {
        background: #F7F7F7;
      }
    </style>
  </head>
  <body>
    <div class="container"> 
      <div class="section" >
        <div class="column is-6 is-offset-3">
          <center>
            <h1 class="title" style="padding-top: 20px">OnlineTrader Deactivator</h1><br>
          </center>
          <div class="box">
            <article class="message is-success">
              <div class="message-body">
                Click on deactivate license to deactivate and remove the currently installed license from this installation, So that you can activate the same license on some other domain.
              </div>
            </article>
            <?php
              if(!empty($_POST)){
               
                $deactivate_response = $api->deactivate_license();
                if(empty($deactivate_response)){
                  $msg='Server is unavailable.';
                }else{
                  $msg=$deactivate_response['message'];
                }
                if($deactivate_response['status'] != true){ ?>
                  <form action="revoke" method="POST">
                    <div class="notification is-danger"><?php echo ucfirst($msg); ?></div>
                    <input type="hidden" name="something">
                    <center>
                      <button type="submit" class="button is-warning">Deactivate License</button>
                    </center>
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                  </form><?php
                }else{ ?>
                  <div class="notification is-success"><?php echo ucfirst($msg); ?></div><?php 
                }
              }else{ ?>
                <form action="revoke" method="POST">
                  <input type="hidden" name="something">
                  <center>
                    <button type="submit" class="button is-warning">Deactivate License</button>
                  </center>
                  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                </form><?php 
              } ?>
          </div>
        </div>
      </div>
    </div>
    <div class="content has-text-centered">
      <p>Copyright <?php echo date('Y'); ?> Brynamics, All rights reserved.</p><br>
    </div>
  </body>
</html><?php /**PATH C:\Users\VICTORY.E\Documents\Brynamics\New Version\Online-Trade-2021\resources\views/revoke/index.blade.php ENDPATH**/ ?>