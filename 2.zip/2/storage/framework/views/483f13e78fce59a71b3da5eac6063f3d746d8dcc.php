<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'inline-flex items-center btn btn-secondary px-4 py-2 border'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\VICTORY.E\Documents\Brynamics\New Version\Online-Trade-2021\resources\views/vendor/jetstream/components/secondary-button.blade.php ENDPATH**/ ?>