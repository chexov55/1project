<?php echo $__env->make('home.assetss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="d-flex flex-column h-100 auth-page">
    <!-- ======= Loginup Section ======= -->
    <div x-data="{ recovery: false }">
        
        <section class="auth">
            <div class="container">
                <div class="row justify-content-center user-auth">
                    <div class="col-12 col-md-6 col-lg-6 col-sm-10 col-xl-6 ">
                        <div class="mb-4 text-center">
                            <a href="<?php echo e(url('/')); ?>" ><img class="auth__logo img-fluid" 
                                src="<?php echo e($settings->site_address); ?>/cloud/app/images/<?php echo e($settings->logo); ?>" alt="<?php echo e($settings->site_name); ?>"> 
                            </a>
                        </div>
                        
                        <div class="card ">
                            <div class="mb-4 text-center">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <div class="mb-4 text-sm text-center text-dark" x-show="! recovery">
                                    <?php echo e(__('Please confirm access to your account by entering the authentication code provided by your authenticator application.')); ?>

                                </div>
                        
                                <div class="mb-4 text-sm text-center text-dark" x-show="recovery">
                                    <?php echo e(__('Please confirm access to your account by entering one of your emergency recovery codes.')); ?>

                                </div>
                            </div>
                            <form method="POST" action="<?php echo e(route('two-factor.login')); ?>" class="mt-5 card__form">
                                <?php echo csrf_field(); ?>
                
                                <div class="mt-4" x-show="! recovery">
                                    <label for="code"><?php echo e(__('Code')); ?></label>
                                    <input id="code" type="text" inputmode="numeric" class="form-control" name="code" autofocus x-ref="code" autocomplete="one-time-code">
                                </div>
                
                                <div class="mt-4" x-show="recovery">
                                    <label for="recovery_code" ><?php echo e(__('Recovery Code')); ?></label>
                                    <input id="recovery_code" class="block w-full mt-1 form-control" type="text" name="recovery_code" x-ref="recovery_code" autocomplete="one-time-code">
                                </div>
                
                                <div class="flex items-center justify-end mt-4 text-center">

                                    <button type="button" class="text-sm text-gray-600 underline cursor-pointer hover:text-gray-900"
                                                    x-show="! recovery"
                                                    x-on:click="
                                                        recovery = true;
                                                        $nextTick(() => { $refs.recovery_code.focus() })
                                                    ">
                                        <?php echo e(__('Use a recovery code')); ?>

                                    </button>
                
                                    <button type="button" class="mt-4 btn btn-primary"
                                                    x-show="recovery"
                                                    x-on:click="
                                                        recovery = false;
                                                        $nextTick(() => { $refs.code.focus() })
                                                    ">
                                        <?php echo e(__('Use an authentication code')); ?>

                                    </button>
                
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'mt-4 btn btn-primary']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-4 btn btn-primary']); ?>
                                        <?php echo e(__('Log in')); ?>

                                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        
        </section>
        
    </div>
    </body>
</html>
<?php /**PATH C:\Users\VICTORY.E\Documents\Brynamics\New Version\Online-Trade-2021\resources\views/auth/two-factor-challenge.blade.php ENDPATH**/ ?>