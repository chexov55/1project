<?php echo e($slot); ?>

<?php /**PATH /home/bryngrgz/onlinefx.brynamics.xyz/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>