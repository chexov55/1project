<?php echo e($slot); ?>

<?php /**PATH C:\Users\VICTORY.E\Documents\Brynamics\New Version\Online-Trade-2021\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>